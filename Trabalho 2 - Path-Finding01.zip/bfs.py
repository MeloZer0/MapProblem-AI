from collections import deque
from mapProblem import MapProblem  # Importa a classe do teu arquivo

# Classe para armazenar cada nó da procura
class Node:
    def __init__(self, state, parent=None, action=None):
        self.state = state    # Estado atual (objeto MapProblem)
        self.parent = parent  # Nó pai (anterior)
        self.action = action  # Ação que levou até aqui

# Função para reconstruir o caminho de ações desde o nó final até o inicial
def extract_solution(node):
    actions = []
    while node.parent is not None:   # Enquanto não chegou à raiz
        actions.append(node.action)  # Adiciona a ação que levou ao nó atual
        node = node.parent           # Vai para o nó pai
    actions.reverse()                # Inverte para ficar na ordem correta (do início ao objetivo)
    return actions

# Implementação da Busca em Largura (BFS)
def breadth_first_search(initial_problem):
    # Cria o nó inicial da procura
    root = Node(initial_problem)

    # Se já está no objetivo, retorna a solução imediatamente
    if root.state.isFinal():
        return extract_solution(root)
    
    # Fronteira: fila FIFO para os nós a serem explorados
    frontier = deque([root])

    # Lista de estados já explorados (evita repetições)
    explored = []

    # Enquanto houver nós na fronteira...
    while frontier:
        # Retira o primeiro nó (BFS é FIFO)
        node = frontier.popleft()

        # Testa se chegou ao objetivo
        if node.state.isFinal():
            return extract_solution(node)

        # Marca este estado como explorado
        explored.append(node.state)

        # Para cada sucessor possível (estado, ação, custo)
        for child_state, action, cost in node.state.succ():
            # Verifica se este estado já foi explorado ou está na fronteira
            already_explored = any(child_state.isEqual(e) for e in explored)
            in_frontier = any(child_state.isEqual(n.state) for n in frontier)
            if not (already_explored or in_frontier):
                # Se é um novo estado, adiciona na fronteira
                frontier.append(Node(child_state, node, action))

    # Se a fronteira esvaziar e não achar solução, retorna None
    return None
