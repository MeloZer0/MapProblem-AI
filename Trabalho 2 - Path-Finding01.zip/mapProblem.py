class MapProblem:
    
    #   Func para saber se 2 mapas são iguais (tamanho, boneco e final)
    
    #   class-point.py (init)
    
    #   if __name__ == "__main__":
    
    """
    Methods:
    __init__ (map (file()))  # Construtor do file (Recebe a lista de listas)

    isFinal() -> bool
    heuristic() -> number   # Manhattan distance
    succ() -> list of (MapProblem, action, cost)    #custo de 1 para todos
    isEqual(MapProblem) -> bool
    
    """
    #   Cada succ cria um novo mapa atualizado

    def __init__(self, map):
        self.map = map
        for i in range(len(map)):
            for j in range(len(map[i])):
                if map[i][j] == '@':
                    self.player = [i, j]
                if map[i][j] == '.':
                    self.goal = [i, j]

    def isFinal(self):
        return self.map[self.player[0]][self.player[1]] == '+'

    def heuristic(self):
        # Distancia manhattan
        return abs(self.player[0] - self.goal[0]) + abs(self.player[1] - self.goal[1])

    def succ(self):
        moves = []
        directions = ["up", "down", "left", "right"]
        
        for direction in directions:
            new_map = [row[:] for row in self.map]
            new_player = self.player.copy()
            
            if self.try_move(new_map, new_player, direction):
                new_problem = MapProblem(new_map)
                moves.append((new_problem, direction, 1))
                
        return moves

    def isEqual(self, other):
        if len(self.map) != len(other.map):
            return False
        for i in range(len(self.map)):
            if len(self.map[i]) != len(other.map[i]):
                return False
            for j in range(len(self.map[i])):
                if self.map[i][j] != other.map[i][j]:
                    return False
        return True

    def try_move(self, map, player, direction):
        # Cópia das coordenadas atuais do jogador
        new_l = player[0]
        new_c = player[1]

        # Calcula as novas coordenadas consoante a direção
        if direction == "up":
            new_l -= 1
        elif direction == "down":
            new_l += 1
        elif direction == "left":
            new_c -= 1
        elif direction == "right":
            new_c += 1
        else:
            # Direção inválida
            return False

        # Verifica se as novas coordenadas estão dentro dos limites do mapa
        if not (0 <= new_l < len(map) and 0 <= new_c < len(map[0])):
            return False

        # Verifica se o novo local é um obstáculo
        if map[new_l][new_c] == '#':
            return False

        # Atualiza o mapa consoante o tipo de célula
        if map[new_l][new_c] == '.':
            map[new_l][new_c] = '+'  # Marca a nova posição do jogador no objetivo
        else:
            map[new_l][new_c] = direction  # Marca a nova posição do jogador

        # Atualiza a posição do jogador
        player[0] = new_l
        player[1] = new_c

        return True
